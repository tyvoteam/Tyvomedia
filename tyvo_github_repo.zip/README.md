# TYVO Media — Website

This is the official website source for **TYVO Media**.

## Deploy on GitHub Pages
1. Upload all files to a public GitHub repository.
2. Go to **Settings → Pages**
3. Select:
   - Source: *Deploy from a branch*
   - Branch: `main`
   - Folder: `/root`
4. Save and wait a few seconds.

Your website will be published automatically.
